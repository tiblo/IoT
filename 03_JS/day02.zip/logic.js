let e = 1;
let f = 5;
let g = 10;
let h = 10;

//compare.js에 선언되어 있는 변수 r 재활용
//(가급적이면 하지 말자)
r = e < f && g >= h;
console.log("r : ", r);