let a = 100;
let b = 50;

let r = a == b;
console.log("a == b : ", r);

r = a > b;
console.log("a > b : ", r);

let c = 1000;
let d = "1000";
console.log("c == d : ", c == d);
console.log("c !== d : ", c !== d);

// 변수에 저장된 자료유형 검사 명령어 : typeof
console.log(typeof c);
console.log(typeof d);

// d는 문자열이므로 숫자로 변환하여 이 후 작업 진행.
d = Number(d);