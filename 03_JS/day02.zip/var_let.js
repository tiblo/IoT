console.log("선언 전 v1 : ", v1); // 호이스팅 가능

var v1 = 100;
console.log("선언 후 v1 : ", v1);

var v1 = 200;   // 중복선언 가능
console.log("중복선언 후 v1 : ", v1);

// console.log("선언 전 v2 : ", v2);
let v2 = 300;
console.log("선언 후 v2 : ", v2);

// let v2 = 400; // 중복 불가