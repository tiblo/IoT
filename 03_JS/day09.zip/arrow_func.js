// 화살표 함수 작성법
//1. function 키워드를 사용하지 않고 => 를 사용.
let func0 = function(a){
    return `${a}입니다.`;
}

let func1 = (a) => {
    return `${a}입니다.`;
}
//1-1 매개변수가 1개면 '(', ')'를 생략
let func2 = a => {
    return `${a}입니다.`;
}
//매개변수가 2개 이상이면 '(', ')'를 생략할 수 없다.

//2. return 문만 있는 단일 표현식 화살표 함수인 경우
//  '{', '}'와 return을 생략
let func3 = a => `${a}입니다.`;

//3. return 문이 없는 단일 표현식 화살표 함수인 경우
let x;
let func4 = a => {
    x = a;
}
// 이 때, '{', '}'를 생략할 수 없다.

//4. 함수의 처리문이 단일 표현식이 아닌 경우
let func5 = (a, b) => {
    let sum = a + b;
    console.log(sum);
    return sum;
}
// 이 때 '{', '}'와 return을 생략할 수 없다.

// remove_elem.html의 empty 버튼 함수
$("#em").click(() => {
    $(".paren").empty();
});

//아래 두 함수는 같은 함수임.
let add1 = (a, b) => a + b;

let add2 = function(a, b){
    return a + b;
}

// 사용 시
let sum = add1(10, 20);