const btn = document.querySelector("#btn");
const year = document.querySelector("#year");
const month = document.querySelector("#month");
const cal = document.querySelector("#calendar");

btn.onclick = function(){
    let y = Number(year.value);
    let m = Number(month.value);

    const fdw = new Date(y, m - 1, 1).getDay();
    const ld = new Date(y, m, 0).getDate();

    let htmlstr = `<h3>${y}년 ${m}월</h3>`;

    //요일 출력
    htmlstr += `<div class="grid">
                    <div class="weekday">일</div>
                    <div class="weekday">월</div>
                    <div class="weekday">화</div>
                    <div class="weekday">수</div>
                    <div class="weekday">목</div>
                    <div class="weekday">금</div>
                    <div class="weekday">토</div>`;

    // 빈칸 넣기
    for(let i = 0; i < fdw; i++){
        htmlstr += `<div class="day empty"></div>`;
    }

    // 날짜 출력
    for(let d = 1; d <= ld; d++){
        htmlstr += `<div class="day">${d}</div>`;
    }

    htmlstr += "</div>";

    cal.innerHTML = htmlstr;
}